www.megamario.de
      ___           ___           ___           ___     
     /\  \         /\__\         /\__\         /\  \    
    |::\  \       /:/ _/_       /:/ _/_       /::\  \   
    |:|:\  \     /:/ /\__\     /:/ /\  \     /:/\:\  \  
  __|:|\:\  \   /:/ /:/ _/_   /:/ /::\  \   /:/ /::\  \ 
 /::::|_\:\__\ /:/_/:/ /\__\ /:/__\/\:\__\ /:/_/:/\:\__\
 \:\~~\  \/__/ \:\/:/ /:/  / \:\  \ /:/  / \:\/:/  \/__/
  \:\  \        \::/_/:/  /   \:\  /:/  /   \::/__/     
   \:\  \        \:\/:/  /     \:\/:/  /     \:\  \     
    \:\__\        \::/  /       \::/  /       \:\__\    
     \/__/         \/__/         \/__/         \/__/    
      ___           ___           ___                       ___     
     /\  \         /\  \         /\  \                     /\  \    
    |::\  \       /::\  \       /::\  \       ___         /::\  \   
    |:|:\  \     /:/\:\  \     /:/\:\__\     /\__\       /:/\:\  \  
  __|:|\:\  \   /:/ /::\  \   /:/ /:/  /    /:/__/      /:/  \:\  \ 
 /::::|_\:\__\ /:/_/:/\:\__\ /:/_/:/__/___ /::\  \     /:/__/ \:\__\
 \:\~~\  \/__/ \:\/:/  \/__/ \:\/:::::/  / \/\:\  \__  \:\  \ /:/  /
  \:\  \        \::/__/       \::/~~/~~~~   ~~\:\/\__\  \:\  /:/  / 
   \:\  \        \:\  \        \:\~~\          \::/  /   \:\/:/  /  
    \:\__\        \:\__\        \:\__\         /:/  /     \::/  /   
     \/__/         \/__/         \/__/         \/__/       \/__/    
_____________________________
www.megamario.de
-----------------------------
full final v1.7 with Gamepad Support 


If you are linux user read "linux.txt".

----------------------------

The game save automatically , after each castle.

Controls : 

H or F1 = Help

Gamepad&Joystick Support is implemented!

Arrow Keys = Movement
Space      = Jump
Left Ctrl  = Run faster / shoot

P = Pause
F12 = Screenshot

###########################################

programmed in C++
		using SDL

Months of work. Work of months.
	

Also play Killer-Mario, where you got some Weapons and mutilate Goombas with a Shotgun.
(Release Soon)



Thanx to Hans de Goede for Linux support!
 and  to Jason Cox for most of the mp3 songs.
 and  to the player of the piano music (send an mail, so I can list you here)	

AND to Vincent Bethmann  for designing some new levels an graphics!!!




www.megamario.de


Email: info@megamario.de



FAQ
(you ask - i answer)



1.
I have got problems with the screen and resolution..
 
- Open "MARIO.ini" and change/add SCREEN_W and SCREEN_H to eg. 800/600 - 1024/768
!!!This is not suggested, because some graphical errors will show up!!!

2.
The pixelation sucks!

- Open "MARIO.ini" and change pixelation to 0 

3.
The Game is too slow / too fast.

Open "MARIO.ini" and add gamespeed=## (## = speed / default is 65)
eg: 
    gamespeed=65

4.
I'm a lovely child and hate blood.

- So turn it off.


6.
I love Mega Mario

- Marry him.

7.
I'm dying all the time.

- So you should look for invisible lifes.





