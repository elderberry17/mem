//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Editor.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_EDITOR_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDD_Load                        129
#define IDD_STARTDLG                    130
#define IDD_CASTLESETTINGS              132
#define IDC_paintmode_STATICTILE        1007
#define IDC_Textures                    1009
#define IDC_Addtexture                  1010
#define IDC_LoadLevel                   1011
#define IDC_FILENAME                    1013
#define IDC_CANCEL                      1014
#define IDC_PATH                        1015
#define IDC_paintmode_PILZ              1016
#define IDC_paintmode_LIFE              1017
#define IDC_paintmode_STAR              1018
#define IDC_paintmode_4                 1019
#define IDC_paintmode_coin              1020
#define IDC_paintmode_invlife           1021
#define IDC_paintmode_CRACKBOX2         1022
#define IDC_Q_BOX_COIN                  1023
#define IDC_paintmode_GOOMBA            1024
#define IDC_paintmode_TURTLE            1025
#define IDC_paintmode_PLAYER            1026
#define IDC_SaveLevel                   1027
#define IDC_newLevel                    1028
#define IDC_paintmode_SPINY             1029
#define IDC_startpointscomba            1032
#define IDC_sEXITpointscomba2           1033
#define IDC_COMBOSTART2                 1034
#define IDC_PAINT                       1035
#define IDC_COMBOEXITSTARPOITM          1036
#define IDC_update                      1037
#define IDC_PAINTEXIT                   1038
#define IDC_updateEXIT                  1039
#define IDC_ANIM                        1040
#define IDCELVELNAME                    1041
#define IDC_showLevel                   1042
#define IDC_paintmode_FIRE              1043
#define IDC_paintmode_FIRE2             1044
#define IDC_CASTELATION                 1044
#define IDC_paintmode_FIRE3             1045
#define IDC_paintmode_FIRE4             1046
#define IDC_COMBATYPE                   1046
#define IDC_paintmode_BLUME             1047
#define IDC_nextlevel                   1047
#define IDC_paintmode_CANNON            1048
#define IDC_REMOVE                      1049
#define IDC_paintmode_BRETT             1049
#define IDC_RELOAD                      1050
#define IDC_HAMMERCOMBO                 1051
#define IDC_BOWSER                      1052
#define IDC_paintmode_TURTLEFLY3        1053
#define IDC_RESTARTLEVEL                1054
#define IDC_INFO                        1055
#define IDC_MASSES                      1056

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1057
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
