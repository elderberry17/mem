/********************************************************************
  Mega Mario SRC
    created:	2005/09/18
	created:	18:9:2005   10:13
	author:		Jens Wellmann (c)
*********************************************************************/


void MenuEvent();
void showMenu();

void initMenu();
void loadlevellist();

void drawInGameStats();
